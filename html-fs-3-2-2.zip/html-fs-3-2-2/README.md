# HTML-FS-3-2. Задача 2. Выбор города.

A Pen created on CodePen.io. Original URL: [https://codepen.io/Vovusja/pen/KKoqxPa](https://codepen.io/Vovusja/pen/KKoqxPa).

